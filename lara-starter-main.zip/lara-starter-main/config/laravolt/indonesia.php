<?php

return [
    'table_prefix' => '',
];
